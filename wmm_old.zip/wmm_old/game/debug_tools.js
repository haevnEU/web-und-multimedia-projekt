class DebugTools{
    constructor(){

    }


    static updateState(message){
        console.log(message);
    }
}

export {DebugTools}