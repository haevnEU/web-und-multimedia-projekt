import {Shape, ShapeHandler} from "./shapes.js"
import {Board} from "./board.js"

class Physics{
    constructor(){

    }

doesCollideDrop(shape,board){
let shapeX = shape.getX();
let shapeY = shape.getY()+1;

for(let x=0;x<4;x++){
    for(let y=3;y>=0;y--){
        if(shape.getElement(x,y)!=0){
            if(board.getBoardElementAt(shapeX+x,shapeY+y)!=0){
                return true;
            }
        }
    }
}


}



    collideLeftWall(shape, board){
        let desiredPosition = shape.getX() - 1;
        
        return desiredPosition <= 0;
    }

    collideRightWall(shape, board){
        let desiredPosition = shape.getX() + 1;
        return desiredPosition > board.getBoardWidth();
    }



}
export{Physics};