class Renderer{
    constructor(){

    }

    
}

export{Renderer}